﻿namespace Umfg.Exercicio._02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            decimal cotacaoReal = 5.22m;

            Console.WriteLine("Digite um valor para fazer a Conversao");
            string valor = Console.ReadLine();

            if (decimal.TryParse(valor, out decimal valorConvertido))
            {
                Console.WriteLine(" O valor convertido é igual a: " + valorConvertido * cotacaoReal + " Reais");
                return;

            }
            Console.WriteLine("O Valor deve ser um numero");

        }
    }
}
