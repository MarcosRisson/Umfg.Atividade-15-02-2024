﻿namespace Umfg.Exercicio._05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-----Caculadora-----");
            Console.WriteLine("1- -------Soma------");
            Console.WriteLine("2- ----Subtracao----");
            Console.WriteLine("3- --Multiplicacao--");
            Console.WriteLine("4- -----Divisao-----");
            Console.WriteLine("5- Resto da Divisao-");

            string opcao = Console.ReadLine();

            Console.WriteLine("Informe O primeiro Numero");
            if (!float.TryParse(Console.ReadLine(), out float primeiroNumero))
                return;

            Console.WriteLine("Informe o Segundo Numero");
            if (!float.TryParse(Console.ReadLine(), out float segundoNumero))
                
                return;
            Console.WriteLine("---");
            switch (opcao)
            {
                case "1":
                    Console.WriteLine(primeiroNumero + segundoNumero);
                    break;

                case "2":
                    Console.WriteLine(primeiroNumero - segundoNumero);
                    break;

                case "3":
                    Console.WriteLine(primeiroNumero * segundoNumero);
                    break;

                case "4":
                    if(segundoNumero <=0)
                        return;
                    Console.WriteLine(primeiroNumero / segundoNumero);
                    break;

                case "5":
                    if (segundoNumero <= 0)
                        return;
                    Console.WriteLine(primeiroNumero % segundoNumero);
                    break;

                default:
                    Console.WriteLine("Opiçao Invalida");
                    break;
            }
        }


    }
}
