﻿namespace Umfg.Exercicio._03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite a Quilometragem Percorrida");
            string quilometros = Console.ReadLine();

            Console.WriteLine("Digite Agora o seu Gasto de Combustivel");
            string litros = Console.ReadLine();

            if (float.TryParse(quilometros, out float quilometrosF)
                && float.TryParse(litros, out float litrosF))
            {

                Console.WriteLine("Media de Gasto do Automovel é: " + quilometrosF / litrosF);
                return;
            }
            Console.WriteLine("Digite apenas Numeros");
        }
    }
}
