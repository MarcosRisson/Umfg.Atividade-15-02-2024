﻿namespace Umfg.Exercicio._07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string vogais = "AEIOUaeiou";
            int contagemVogais = 0;

            Console.WriteLine("Digite o seu nome: ");
            string nomeUsuario = Console.ReadLine();

            foreach (char caractere in nomeUsuario)
            {
                if (vogais.IndexOf(caractere) < 0)
                {
                    contagemVogais++;
                }
            }
            Console.WriteLine("Quantidade de consoantes em seu nome: " + contagemVogais);
        }
    }
}
