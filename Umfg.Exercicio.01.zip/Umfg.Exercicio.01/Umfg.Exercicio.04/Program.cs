﻿namespace Umfg.Exercicio._04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string anoAtual = DateTime.Now.ToString("yyyy");

            Console.WriteLine("Informe sua Data de Nascimento");
            string anoNascimento = Console.ReadLine();

            if (int.TryParse(anoNascimento, out int nascimento))
            {
                int.TryParse(anoAtual, out int idadeAtual);

                Console.WriteLine("Sua Idade é: " + (idadeAtual - nascimento));
                return;
            }
                Console.WriteLine("Numero Invalido");

        }
    }
}
