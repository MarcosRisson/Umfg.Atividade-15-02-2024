﻿namespace Umfg.Exercicio._01
{
    internal class Program
    {
        static void Main(string[] args)
        {

            decimal cotacaoDolar = 0.193259m;

            Console.WriteLine("Digite um valor para fazer a Conversao");
            string valor = Console.ReadLine();

            if(decimal.TryParse(valor, out decimal valorConvertido) )
            {
                Console.WriteLine(" O valor convertido é igual a: " + valorConvertido * cotacaoDolar + " Dolares");
                return;

            }
            Console.WriteLine("O Valor deve ser um numero");

        }
    }
}
